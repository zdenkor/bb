# Test files

Files to allow the IniFile library to be developed and tested under a
standard g++ environment.

## Makefile targets

    make ini_test
Make the test program.

    make run
Make and run the test program.

    make regressiontest
Run regression tests.

    make clean
Remove some non-source files.

    make realclean
Remove all non-versioned files.

