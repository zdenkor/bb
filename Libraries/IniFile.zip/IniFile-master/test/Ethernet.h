#ifndef _ETHERNET_H
#define _ETHERNET_H


#include "IPAddress.h"

#endif
